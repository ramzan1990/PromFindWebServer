Predicting:

java -jar PromID.jar -set temp.fa -out temp.out -mode 1 -md 1000 -dt1 0.5 -dt2 0.5 -step 1 -mat tata.txt

Mandatory:  
-set: input file 
-out: output file 

Optional:
-mode: 0 is for 1 model, 1 is for 2 models, 2 is for 2 models with TATA-box matrix. Default is 0.
-md: minimum distance between promoters, default is 1000
-dt1: decision threshold for model_1, default is 0.5 
-dt2: decision threshold for model_2(TATA+), default is 0.5
-step: stride of the sliding window, default is 1
-mat: file with TATA matrix

Drawing scoring landscapes:

java -jar draw.jar -setp forDraw/model_1.res -out temp/pics

-setp: predictions from PromID.jar (located in folder forDraw)
-out: output directory
-w: width of one landscape
-h: height of one landscape
-count: number of graphs per picture 
-maxf: maximum number of generated files (default 5000) 